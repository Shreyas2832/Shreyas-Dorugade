DamSafety India - Offline Standalone Mobile Package
==================================================
How to run on your Android mobile phone without internet:
1. Connect your phone to your computer via USB cable.
2. Copy this entire folder to your phone (e.g. into Downloads or Internal Storage).
3. On your phone, open the Chrome or Samsung Internet app.
4. Type file:///sdcard/Download/index.html or tap index.html in your phone's File Manager.
5. All 5,300+ dams, hydrodynamic models, sensors, and sirens work 100% offline!
