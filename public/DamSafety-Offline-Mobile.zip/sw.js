/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "fc8fa7fe89e3c6d124586acd8e2b9c40"
  }, {
    "url": "pwa-512x512.png",
    "revision": "371ab121dea5e1f3efd7ac1c2bbd7367"
  }, {
    "url": "pwa-192x192.png",
    "revision": "7f725fafcf01646abd543123ecc988bd"
  }, {
    "url": "index.html",
    "revision": "1f4b1e72dc44c203bdb7e7364f17cd3c"
  }, {
    "url": "icon.svg",
    "revision": "6c2f9651c3aadfe6cdc2fedc1636d371"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "92745e6cf2531a09a6d8d5c6b4413a54"
  }, {
    "url": "assets/purify.es-DBIK8olT.js",
    "revision": null
  }, {
    "url": "assets/index.es-CESFVaY-.js",
    "revision": null
  }, {
    "url": "assets/index-DAa3Wy7f.js",
    "revision": null
  }, {
    "url": "assets/index-CMSZdZ6y.css",
    "revision": null
  }, {
    "url": "assets/html2canvas.esm-QH1iLAAe.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "92745e6cf2531a09a6d8d5c6b4413a54"
  }, {
    "url": "icon.svg",
    "revision": "6c2f9651c3aadfe6cdc2fedc1636d371"
  }, {
    "url": "pwa-192x192.png",
    "revision": "7f725fafcf01646abd543123ecc988bd"
  }, {
    "url": "pwa-512x512.png",
    "revision": "371ab121dea5e1f3efd7ac1c2bbd7367"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "fc8fa7fe89e3c6d124586acd8e2b9c40"
  }, {
    "url": "manifest.webmanifest",
    "revision": "072932292690530ff2d4f0c34cb424a0"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
